console.log("hello world")
console.log('A' - 1)
console.log(2 + '2' + '2')
console.log('hello' + 'world' + 89)
console.log('hello' - 'world' + 89)
console.log('hello'+78)
console.log('78' - 90 + '2');
console.log(2 - '2' + 90);
console.log(89 - '90' / 2);
console.log((true == false) > 2);